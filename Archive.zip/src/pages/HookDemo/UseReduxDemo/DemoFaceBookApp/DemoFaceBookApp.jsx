//rfc
import React from 'react'
import { useSelector } from 'react-redux'
export default function DemoFaceBookApp(props) {


    const { arrComment } = useSelector(state => state.facebookReducer);
    console.log(arrComment);

    const renderComment = () => {
        return arrComment.map((comment, index) => {
            return <div className='row mt-2' key={index}>
                <div className='col-2'>
                    <img src={`https://i.pravatar.cc?u=${comment.name}`} alt="avatar" className='w-100' />
                </div>
                <div className='col-10'>
                    <h3 className='text-danger'>{comment.name}</h3>
                    <p>{comment.content}</p>
                </div>
            </div>
        })
    }
    return (
        <div className='container'>
            <h3>Demo facebook app</h3>
            <div className='card'>
                <div className='card-header'>
                    {renderComment()}
                </div>
                <div className='card-body'>
                    <form className='frm'>
                        <div className='form-group'>
                            <p>name</p>
                            <input className='form-control' id="name" />
                        </div>
                        <div className='form-group'>
                            <p>content</p>
                            <input className='form-control' id="content" />
                        </div>
                        <div className='form-group'>
                            <button type='submit' className='btn btn-success'>Send</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    )
}
