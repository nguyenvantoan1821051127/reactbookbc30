//rxslice
import { createSlice } from '@reduxjs/toolkit'


//state.facebookReducer = 
const initialState = {
    arrComment: [
        {name:'Khải',content: 'hihi 123'},
        {name:'Hậu',content: 'hihi 456'},
    ]
}

const facebookReducer = createSlice({
  name: 'facebookReducer', //tên nối với tên action
  initialState,
  reducers: {

  }
});

export const {} = facebookReducer.actions

export default facebookReducer.reducer

//---------------------- action ------------------